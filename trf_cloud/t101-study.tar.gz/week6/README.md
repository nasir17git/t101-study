# 6주차 과제

# 민감정보를 안전하게 관리하는 테스트 수행

- random_password 리소스를 사용한 암호 생성 자동화
- RDS 생성시 Parameter store, Secrets manager를 통한 암호 전달

# 생성 결과 및 암호 조회

<a href="https://ibb.co/2F19J0b"><img src="https://i.ibb.co/Cw3cLpr/2022-11-27-02-53-51.png" alt="2022-11-27-02-53-51" border="0"></a>